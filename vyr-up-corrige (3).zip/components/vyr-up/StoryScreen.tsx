'use client'

import { ArrowRight } from 'lucide-react'
import { AnimatedNumber, FlowTop } from './shared'

export function StoryScreen({ onContinue, onBack }: { onContinue: () => void; onBack: () => void }) {
  return (
    <div className="flow-shell">
      <FlowTop step={4} onBack={onBack} />
      <section className="story-panel stage-enter">
        <span className="section-label">250 000+ PROFILS DÉCRYPTÉS</span>
        <h1>LES VUES NE SONT PAS<br />UNE QUESTION DE <em>CHANCE.</em></h1>
        <p>Les créateurs qui progressent lisent leurs signaux, répètent leurs formats forts et corrigent leurs vidéos faibles.</p>
        <div className="story-stat">
          <strong><AnimatedNumber value={250000} suffix="+" /></strong>
          <span>créateurs ont déjà remplacé l’intuition par une méthode.</span>
        </div>
        <button className="primary-action" onClick={onContinue}>
          <span>Voir ce que mes données disent</span><ArrowRight />
        </button>
      </section>
    </div>
  )
}
