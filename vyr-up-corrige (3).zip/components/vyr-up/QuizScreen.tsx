'use client'

import { ChevronRight, Sparkles } from 'lucide-react'
import { questions } from './quiz-data'
import { FlowTop } from './shared'

export function QuizScreen({ step, answer, onAnswer, onBack }: { step: number; answer?: string; onAnswer: (value: string) => void; onBack: () => void }) {
  const question = questions[step]
  return (
    <div className="flow-shell quiz-flow">
      <FlowTop step={step} onBack={onBack} />
      <div className="quiz-aura" aria-hidden="true" />
      <section className="quiz-panel stage-enter" key={question.id}>
        <div className="question-copy">
          <span className="section-label">{question.eyebrow}</span>
          <h1>{question.title}</h1>
          <p>{question.subtitle}</p>
        </div>
        <div className="answer-grid">
          {question.options.map((option, index) => {
            const Icon = option.icon
            return (
              <button
                className={[answer === option.label ? 'selected' : '', option.comingSoon ? 'soon' : ''].filter(Boolean).join(' ')}
                style={{ '--delay': `${index * 85}ms` } as React.CSSProperties}
                key={option.label}
                disabled={option.comingSoon}
                aria-disabled={option.comingSoon}
                onClick={() => { if (!option.comingSoon) onAnswer(option.label) }}
              >
                <span className="answer-icon"><Icon /></span>
                <b>{option.label}{option.comingSoon && <em className="soon-tag">Bientôt</em>}</b>
                <ChevronRight className="answer-arrow" />
              </button>
            )
          })}
        </div>
        <p className="keyboard-hint mono-note"><Sparkles /> Choisis une réponse pour continuer automatiquement</p>
      </section>
    </div>
  )
}
